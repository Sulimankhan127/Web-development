// Javascript code for hide/show form

// // User Accounts
// const acc1 = {
//     login_email: 'salmanKhan127@gmail.com',
//     login_password: 'khan127'
// };

// const acc2 = {
//     login_email: 'ghulamtahir6@gmail.com',
//     login_password: 'tahir105'
// };
// // Array of accounts
// const Accounts = [acc1, acc2];


// To open the form 
function openForm() {
    let formContainer = document.querySelector('.form-Container');
    formContainer.style.display = 'block';
    let loginForm = document.querySelector('.login-form');
    loginForm.style.display = 'block'; // Show the login form
}

// To open signup form
function openSignupForm() {
    let formContainer = document.querySelector('.form-Container');
    formContainer.style.display = 'block';
    let signupForm = document.querySelector('.signup-form');
    signupForm.style.display = 'block'; // Show the signup form
    let loginForm = document.querySelector('.login-form');
    loginForm.style.display = 'none'; // hide the login form
}
// To show  Login form after signup
function login() {
    let formContainer = document.querySelector('.form-Container');
    formContainer.style.display = 'block';
    let login = document.querySelector('.login-form');
    login.style.display = 'block'; // Show the login form
    let signupForm = document.querySelector('.signup-form');
    signupForm.style.display = 'none'; // Hide the signup form
}

// To close the form
function closeForm() {
    let formContainer = document.querySelector('.form-Container');
    formContainer.style.display = 'none';
    let signupForm = document.querySelector('.signup-form');
    signupForm.style.display = 'none'; // Hide the signup form
}


// Show/save Email and Password 
// -----> Global variables
const user_email_textfield = document.getElementById('login-email');
const user_pass_textfield = document.getElementById('login-pass');
const user_login_button = document.querySelector('#login-btn');
let email_user = password_user = '';

// ---> Signup Variables
const signup_email_input = document.getElementById('signup-email-input');
const signup_pass = document.getElementById('signup-pass-input');
const signup_pass_cfm = document.getElementById('signup-pass-input_cfrm');
const signup_btn = document.getElementById('signup-btn');


// Array for signup accounts
const Accounts = [];

// signup Function
signup_btn.addEventListener('click', function () {
    const sign_email = signup_email_input.value;
    const sign_pass = signup_pass.value;
    const sign_pass_cfrm = signup_pass_cfm.value;

    if (sign_pass === sign_pass_cfrm) {
        const obj = {
            login_email: `${sign_email}`,
            login_password: `${sign_pass}`
        };
        Accounts.push(obj);
        console.log(Accounts);
    }
    else {
        alert('Passwords do not Match!');
    }

});

// To fined account
user_login_button.addEventListener('click', function () {
    email_user = user_email_textfield.value;
    password_user = user_pass_textfield.value;
    const emailvalid = Accounts.find((account) => account.login_email === email_user);
    console.log(emailvalid);
    if (emailvalid) {
        const passvalid = emailvalid.login_password === password_user;
        console.log('Login Successfull : )');
    }
    else {
        console.log('Account Not Found');
    }
})

// To hide/show password through click on icon
const pwShowHide = document.querySelector(".pw_hide");
pwShowHide.addEventListener("click", () => {
    let getPwInput = pwShowHide.parentElement.querySelector("input");
    if (getPwInput.type === "password") {
        getPwInput.type = "text";
        pwShowHide.classList.replace("fa-eye-slash", "fa-eye")
    } else {
        getPwInput.type = "password";
        pwShowHide.classList.replace("fa-eye", "fa-eye-slash")
    }
});